from django.apps import AppConfig


class PannelConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pannel'
