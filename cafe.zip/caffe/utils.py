def send_otp_code(mobile_phone, code):
    pass